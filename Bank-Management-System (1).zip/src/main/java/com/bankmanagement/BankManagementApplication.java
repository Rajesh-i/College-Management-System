package com.bankmanagement;
public class BankManagementApplication { public static void main(String[] args){ System.out.println("Bank Management System"); } }